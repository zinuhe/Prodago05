import { Component } from '@angular/core';

@Component({
  selector: 'app-main-container',
  templateUrl: './mainContainer.component.html'
  // styleUrls: ['./menu.component.css']
})

export class MainContainerComponent {
  pageTitle: string = '-menu-';
  title = 'menu';
}
