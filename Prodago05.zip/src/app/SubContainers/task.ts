export interface ITask {
  taskId: number;
  priority: number;
  description: string;
  status: string;
  dueDate: string;
}
